package com.example.electrobus

class User(val name: String,
           val matricula: String,
           val email: String,
           val password: String,
           val typeUser: String) {


}